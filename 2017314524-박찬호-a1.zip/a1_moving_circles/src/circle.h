#pragma once
#ifndef __CIRCLE_H__
#define __CIRCLE_H__

struct circle_t
{
	vec2	center = vec2(0);		// 2D position for translation
	float	radius = 1.0f;		// radius
	float	theta = 0.0f;			// rotation angle
	vec2	velocity = vec2(0);	// velocity
	vec4	color;				// RGBA color in [0,1]
	mat4	model_matrix;		// modeling transformation

	// public functions
	void	update(float delta_t);
};

const float  max_radius = 0.7f, min_radius = 0.2f;
const float right_side = (8.0f / 4.5f), left_side = -(8.0f / 4.5f);
const float  up_side = 1.0f, down_side = -1.0f;

inline float get_sq(vec2 v)
{
	return (v.x * v.x) + (v.y * v.y);
}

inline bool check_side_collision(float x, float y, float radius)
{
	bool x_check = ((x + radius) < right_side) && ((x - radius) > left_side);
	bool y_check = ((y + radius) < up_side) && ((y - radius) > down_side);

	return !(x_check && y_check);
}

inline float get_rand_p(void)
{
	return rand() / ((float)RAND_MAX);
}

inline std::vector<circle_t> create_circles(const uint n_circles)
{
	std::vector<circle_t> circles;
	circle_t c;

	for (uint i = 0; i < n_circles; i++) {
		float x, y, p, radius, R, G, B, v_x, v_y;

		while (true) {
			bool collision = false;
			p = get_rand_p();
			x = (2 * right_side) * p - right_side;

			p = get_rand_p();
			y = (2 * up_side) * p - up_side;

			vec2 pos = { x, y };

			p = get_rand_p();
			radius = ((max_radius - min_radius) * p + min_radius) * (1 / (float)sqrt(n_circles));

			for (uint j = 0; j < i; j++) {
				float dis = get_sq(circles[j].center - pos);
				float r_sum = radius + circles[j].radius;
				float r_sum2 = r_sum * r_sum;

				if (r_sum2 > dis) {
					collision = true;
					break;
				}
			}

			if (check_side_collision(x, y, radius)) {
				collision = true;
			}

			if (collision) continue;

			p = get_rand_p();
			v_x = (0.24f * p - 0.12f) / (radius);

			p = get_rand_p();
			v_y = (0.24f * p - 0.12f) / (radius);

			R = get_rand_p();
			G = get_rand_p();
			B = get_rand_p();

			break;
		}

		c = { vec2(x, y), radius, 0.0f, vec2(v_x, v_y), vec4(R, G, B, 1.0f) };
		circles.emplace_back(c);
	}

	return circles;
}

inline void circle_t::update(float delta_t)
{
	theta = delta_t;
	float c = cos(theta), s = sin(theta);
	center.x = center.x + velocity.x * delta_t;
	center.y = center.y + velocity.y * delta_t;

	// these transformations will be explained in later transformation lecture
	mat4 scale_matrix =
	{
		radius, 0, 0, 0,
		0, radius, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};

	mat4 rotation_matrix =
	{
		c,-s, 0, 0,
		s, c, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};

	mat4 translate_matrix =
	{
		1, 0, 0, center.x,
		0, 1, 0, center.y,
		0, 0, 1, 0,
		0, 0, 0, 1
	};

	model_matrix = translate_matrix * rotation_matrix * scale_matrix;
}

#endif