#pragma once
#ifndef __CIRCLE_H__
#define __CIRCLE_H__
#include <random>
#include <iostream>

struct circle_t
{
	vec2	center=vec2(0);		// 2D position for translation
	float	radius=1.0f;		// radius
	float	theta=0.0f;			// rotation angle
	vec4	color;				// RGBA color in [0,1]
	mat4	model_matrix;		// modeling transformation

	vec2	velocity = vec2(0);

	// public functions
	void	update(float timeDiff, bool stop);
};

inline std::vector<circle_t> create_circles(int N)
{
	std::vector<circle_t> circles;
	circle_t c;
	
	float maxRadius = 0.80f, minRadius = 0.20f;
	maxRadius /= (float)sqrt(N), minRadius /= (float)sqrt(N);

	std::random_device rd;
	std::default_random_engine eng(rd());
	std::uniform_real_distribution<float> getRadius(minRadius, maxRadius);
	std::uniform_real_distribution<float> getPosX(-16/(float)9, 16/(float)9);
	std::uniform_real_distribution<float> getPosY((float)(-1), (float)(1));
	std::uniform_real_distribution<float> getColor(0.0f, 1.0f);
	std::uniform_real_distribution<float> getVelocity(-1.0f, 1.0f);

	int cnt = 0;
	bool collision = false;

	while (cnt < N) {
		float radius = getRadius(eng);
		float posX = getPosX(eng);
		float posY = getPosY(eng);

		if (posX + radius >= 16 / (float)9 || posX - radius <= -16 / (float)9) continue;
		if (posY + radius >= (float)(1) || posY - radius <= (float)(-1)) continue;

		collision = false;
		for (size_t i = 0; i < circles.size(); i++) {
			float distance = (float)sqrt(pow(posX - circles[i].center.x, 2) + pow(posY - circles[i].center.y, 2));

			if (distance <= radius + circles[i].radius) {
				collision = true;
				break;
			}
		}

		if (collision == true) continue;

		float R = getColor(eng);
		float G = getColor(eng);
		float B = getColor(eng);

		float velocityX = getVelocity(eng) / (radius * (float)sqrt(N));
		float velocityY = getVelocity(eng) / (radius * (float)sqrt(N));
		
		c = { vec2(posX,posY),radius,0.0f,vec4(R,G,B,1.0f) };
		c.velocity = vec2(velocityX, velocityY);

		circles.emplace_back(c);

		cnt++;
	}

	return circles;
}

inline void circle_t::update( float timeDiff, bool stop )
{
	float c	= cos(theta), s=sin(theta);

	if (stop == false) {
		center.x = center.x + velocity.x * timeDiff;
		center.y = center.y + velocity.y * timeDiff;
	}
	

	// these transformations will be explained in later transformation lecture
	mat4 scale_matrix =
	{
		radius, 0, 0, 0,
		0, radius, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};

	mat4 rotation_matrix =
	{
		c,-s, 0, 0,
		s, c, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	};

	mat4 translate_matrix =
	{
		1, 0, 0, center.x,
		0, 1, 0, center.y,
		0, 0, 1, 0,
		0, 0, 0, 1
	};
	
	model_matrix = translate_matrix*rotation_matrix*scale_matrix;
}

inline void collisionDetection(std::vector<circle_t> &circles, float timeDiff, size_t target) {
	int detection = circles.size();

	while (detection > 0) {
		detection = 0;
		//printf("start detection: %d\n", detection);
		for (size_t i = 0; i < circles.size(); i++) {
			float MoveX = circles[i].center.x + circles[i].velocity.x * timeDiff;
			float MoveY = circles[i].center.y + circles[i].velocity.y * timeDiff;

			if (MoveX + circles[i].radius >= 16 / (float)9 || MoveX - circles[i].radius <= -16 / (float)9) {
				circles[i].velocity.x *= -1.0f;
				detection++;
				//printf("pos: %f, %f - velx: %f, %f(%f) - rad: %f\n", MoveX, MoveY, circles[i].velocity.x, circles[i].velocity.x * timeDiff, timeDiff, circles[i].radius);
			}

			if (MoveY + circles[i].radius >= (float)(1) || MoveY - circles[i].radius <= (float)(-1)) {
				circles[i].velocity.y *= -1.0f;
				detection++;
				//printf("pos: %f, %f - vely: %f, %f(%f) - rad: %f\n", MoveX, MoveY, circles[i].velocity.y, circles[i].velocity.y * timeDiff, timeDiff, circles[i].radius);
			}
		}
		//printf("wall detection: %d\n", detection);
		for (size_t i = 0; i < circles.size(); i++) {
			for (size_t j = i + 1; j < circles.size(); j++) {
				float MoveX_1 = circles[i].center.x + circles[i].velocity.x * timeDiff;
				float MoveY_1 = circles[i].center.y + circles[i].velocity.y * timeDiff;
				float MoveX_2 = circles[j].center.x + circles[j].velocity.x * timeDiff;
				float MoveY_2 = circles[j].center.y + circles[j].velocity.y * timeDiff;

				float distance = (float)sqrt(pow(MoveX_1 - MoveX_2, 2) + pow(MoveY_1 - MoveY_2, 2));

				if (distance <= circles[i].radius + circles[j].radius) {
					float mass_i = circles[i].radius * circles[i].radius;
					float mass_j = circles[j].radius * circles[j].radius;
					vec2 center_i = circles[i].center;
					vec2 center_j = circles[j].center;
					vec2 velocity_i = circles[i].velocity;
					vec2 velocity_j = circles[j].velocity;

					if (target == i || target == j) {
						mass_i = circles[i].radius * circles[i].radius * 1.4f;
						mass_j = circles[j].radius * circles[j].radius;
					}
					circles[i].velocity = velocity_i -
						((2 * mass_j) / (mass_i + mass_j)) *
						(dot(velocity_i - velocity_j, center_i - center_j)) /
						((float)pow((center_i - center_j).length(), 2)) *
						(center_i - center_j);

					if (target == i || target == j) {
						mass_i = circles[i].radius * circles[i].radius;
						mass_j = circles[j].radius * circles[j].radius * 1.4f;
					}
					circles[j].velocity = velocity_j -
						((2 * mass_i) / (mass_i + mass_j)) *
						(dot(velocity_j - velocity_i, center_j - center_i)) /
						((float)pow((center_j - center_i).length(), 2)) *
						(center_j - center_i);

					detection++;
					break;
				}
			}
		}
		//printf("circle detection: %d\n", detection);
	}
}

inline void setGravity(std::vector<circle_t>& circles) {
	for (size_t i = 0; i < circles.size(); i++) {
		float mass = circles[i].radius * circles[i].radius * (float)sqrt(circles.size());
		circles[i].velocity.y -= mass * 0.05f;
	}
}

inline size_t findTargetCircle(std::vector<circle_t>& circles, float x, float y) {
	for (size_t i = 0; i < circles.size(); i++) {
		float distance = (float)sqrt(pow(circles[i].center.x - x, 2) + pow(circles[i].center.y - y, 2));

		if (distance <= circles[i].radius) return i;
	}

	return 1000;
}

inline void setUniversalForce(std::vector<circle_t>& circles, size_t target) {
	for (size_t i = 0; i < circles.size(); i++) {
		if (i == target) continue;

		vec2 dir = circles[target].center - circles[i].center;
		float length = dir.length();
		dir.x /= length;
		dir.y /= length;

		float mass_1 = circles[i].radius * circles[i].radius * (float)sqrt(circles.size());
		float mass_2 = circles[target].radius * circles[target].radius * (float)sqrt(circles.size());

		float force = mass_1 * mass_2 / (float)pow(length, 2);
		dir.x *= force * (0.1f);
		dir.y *= force * (0.1f);
		
		circles[i].velocity = circles[i].velocity + dir;
	}
}

#endif
